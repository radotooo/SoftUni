﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tuple
{
    public class Tuple<T>
    {

        public T item1 { get; set; }
        public T item2 { get; set; }
        public T item3 { get; set; }


        public Tuple(T item1 , T item2,T item3)
        {
            this.item1 = item1;
            this.item2 = item2;
            this.item3 = item3;

        }

      



        public void Print()
        {
            Console.WriteLine($"{item1} -> {item2} -> {item3}");
            
        }

    }
}
