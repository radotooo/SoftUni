﻿using System;
using System.Collections.Generic;

namespace Tuple
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            List<Tuple<object>> tupleList = new List<Tuple<object>>();
            object obj1 = null;
            object obj2 = null;
            object obj3 = null;

            for (int i = 0; i < 3; i++)
            {
                string[] input = Console.ReadLine().Split();


                if (input.Length > 3)
            {
                obj1 = string.Concat(input[0] + " " + input[1]);
                 obj2 = input[2];
                    obj3 = input[3];
            }
            else
            {
                obj1 = input[0];
                obj2 = input[1];
                    obj3 = input[2];
                    if((string)obj3 == "drunk")
                    {
                        obj3 = true;
                    }
                    else if((string)obj3 == "not")
                    {
                        obj3 = false;
                    }
                    else
                    {
                    obj3 = input[2];

                    }

                }
                var result = new Tuple<object>(obj1, obj2,obj3);
            tupleList.Add(result);
            }

            foreach (var item in tupleList)
            {
                item.Print();
            }

            
            
        }
    }
}
