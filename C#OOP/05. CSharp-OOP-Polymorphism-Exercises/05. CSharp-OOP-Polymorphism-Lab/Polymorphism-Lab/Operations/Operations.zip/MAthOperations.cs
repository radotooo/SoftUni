﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operations
{
    public class MathOperations
    {
        public int Add(int b, int c )
        {
            return b + c;
            
        }
        public double Add(double b, double c,double d )
        {
            return b + c + d ;

        }
        public decimal Add(decimal  b, decimal c , decimal a)
        {
            return b + c + a;


        }
    }
}
