﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Food
{
    public abstract class Foods
    {
        public int Quantity { get; protected set; }

        public Foods(int quantity)
        {
            this.Quantity = quantity;
        }
    }
}
