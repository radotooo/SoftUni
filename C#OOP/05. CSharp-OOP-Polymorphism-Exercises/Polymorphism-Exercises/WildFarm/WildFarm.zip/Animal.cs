﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Food;


namespace WildFarm.Animals
{
    public abstract class Animal
    {
        public string Name { get; protected set; }
        public double  Weight { get; protected set; }
        public int FoodEaten { get; protected set; }

        public Animal(string name , double weight )
        {
            this.Name = name;
            this.Weight = weight;
        }

        public abstract string ProduceSound();
        public virtual void Eat(string food , int quantity)
        {
            this.FoodEaten += quantity;
            
        }

    }
}
