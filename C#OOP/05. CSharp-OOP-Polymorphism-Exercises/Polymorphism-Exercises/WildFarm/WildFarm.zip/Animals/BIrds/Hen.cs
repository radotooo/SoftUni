﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Animals.BIrds
{
    public class Hen : Bird
    {
        private const double increase = 0.35;
        public Hen(string name, double weight, double wingSise) : base(name, weight, wingSise)
        {
        }

        public override void Eat(string food, int quantity)
        {
            this.FoodEaten += quantity;
            this.Weight += quantity * increase;

        }

        public override string ProduceSound()
        {
            return $"Cluck";
        }
    }
}
