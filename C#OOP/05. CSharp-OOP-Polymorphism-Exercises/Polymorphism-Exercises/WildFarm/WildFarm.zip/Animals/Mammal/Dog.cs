﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Animals.Mammal
{
   public class Dog : Mammal
    {
        private const double increase = 0.40;

        public Dog(string name, double weight, string region) : base(name, weight, region)
        {
        }

        public override void Eat(string food, int quantity)
        {
            if (food != "Meat")
            {
                throw new ArgumentException($"{ this.GetType().Name} does not eat {food}!");
            }
            base.Eat(food, quantity);
            this.Weight += quantity * increase;
        }

        public override string ProduceSound()
        {
            return $"Woof!";
        }
    }
}
