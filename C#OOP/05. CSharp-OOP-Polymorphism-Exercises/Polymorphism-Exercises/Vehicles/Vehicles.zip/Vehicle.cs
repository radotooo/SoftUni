﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {

        public  double FuelQuantity { get; protected set; }
        public  double FuelConsumption { get; protected set; }

        

        
        public Vehicle(double fuelQuantity , double fuelConsimption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsimption;
            

        }

        public abstract string Drive(double km );

        public override string ToString()
        {

            return $"{this.GetType().Name}: {this.FuelQuantity:F2}";
        }
        public abstract void Refuel(double fuel);
        

    }
}
