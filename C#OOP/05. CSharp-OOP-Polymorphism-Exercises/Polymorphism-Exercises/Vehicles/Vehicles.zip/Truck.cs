﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsimption) : base(fuelQuantity, fuelConsimption)
        {
        }

        

        public override string Drive(double km)
        {
            double currentFuel = (this.FuelConsumption + 1.6) * km;
            if (this.FuelQuantity - currentFuel > 0)
            {
                this.FuelQuantity -= currentFuel;

                return $"{GetType().Name} travelled {km} km";
            }
            else
            {
                return $"{GetType().Name} needs refueling";
            }
        }

      

        public override void Refuel(double fuel)
        {
            this.FuelQuantity += fuel*0.95;
        }
    }
}
