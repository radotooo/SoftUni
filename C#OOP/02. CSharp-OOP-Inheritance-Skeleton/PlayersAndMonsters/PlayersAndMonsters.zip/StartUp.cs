﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var elf = new Elf("Gosho", 99);
            System.Console.WriteLine(elf);
        }
    }
}