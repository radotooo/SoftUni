﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite
{
   public abstract class OoverRide :IPrivate
    {
        public abstract decimal Salary { get;  }

        public abstract string FirstName { get;  }

        public abstract string LastName { get;  }

        public abstract int Id { get;  }

        
    }
}


