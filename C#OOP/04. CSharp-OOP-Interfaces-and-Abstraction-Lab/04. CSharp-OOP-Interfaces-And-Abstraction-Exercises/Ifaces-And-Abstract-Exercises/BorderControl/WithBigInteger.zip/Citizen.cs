﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace BorderControl
{
    public class Citizen : IInterface
    {
        public string Name { get; private set; }
        public int Age { get; private set; }
        public BigInteger Id { get; private set; }

        public Citizen(string name , int age , BigInteger id )
        {
            this.Name = name;
            this.Age = age;
            this.Id = id;
        }
    }
}
