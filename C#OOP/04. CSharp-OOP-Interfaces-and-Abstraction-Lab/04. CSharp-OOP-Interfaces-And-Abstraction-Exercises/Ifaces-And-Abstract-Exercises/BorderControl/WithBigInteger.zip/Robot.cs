﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace BorderControl
{
    public class Robot : IInterface
    {
        public string Model { get; private set; }
        public BigInteger Id { get;private  set; }

        public Robot(string model , BigInteger id)
        {
            this.Model = model;
            this.Id = id;
        }
    }
}
