﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace BorderControl
{
   public  class StartUp
    {
        static void Main(string[] args)
        {
            var visitorsList = new List<IInterface>();
           


            while (true)
            {
                string[] input = Console.ReadLine().Split();
                if(input[0]=="End")
                {
                    break;
                }
                
                if(input.Length == 3)
                {
                    string name = input[0];
                    int age = int.Parse(input[1]);
                    BigInteger id = BigInteger.Parse(input[2]);

                    var citizen = new Citizen(name,age,id);
                    visitorsList.Add(citizen);
                }
                else
                {
                    string model = input[0];
                    
                    BigInteger id = BigInteger.Parse(input[1]);
                    var robot = new Robot(model, id);
                    visitorsList.Add(robot);
                }
                    

            }

            string chek = Console.ReadLine();

            foreach (var visitor in visitorsList)
            {
                if(visitor.Id.ToString().EndsWith(chek))
                {
                    Console.WriteLine(visitor.Id);
                }
            }

           
        }
        
    }
}
