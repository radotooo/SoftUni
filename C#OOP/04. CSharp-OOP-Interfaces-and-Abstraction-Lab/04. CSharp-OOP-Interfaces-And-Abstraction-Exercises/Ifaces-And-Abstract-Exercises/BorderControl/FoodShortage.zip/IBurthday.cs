﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IBurthday
    {
        string Birthday { get; }
        string Name { get; }
        int Age { get;  }
    }
}
