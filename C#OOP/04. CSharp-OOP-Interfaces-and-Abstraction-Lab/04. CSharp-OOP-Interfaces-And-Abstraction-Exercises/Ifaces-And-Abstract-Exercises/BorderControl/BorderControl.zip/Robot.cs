﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Robot : IInterface
    {
        public string Model { get; private set; }
        public long Id { get;private  set; }

        public Robot(string model , long id)
        {
            this.Model = model;
            this.Id = id;
        }
    }
}
