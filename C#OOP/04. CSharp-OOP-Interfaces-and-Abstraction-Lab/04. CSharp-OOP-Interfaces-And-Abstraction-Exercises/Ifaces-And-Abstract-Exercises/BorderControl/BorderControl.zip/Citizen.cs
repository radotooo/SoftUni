﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Citizen : IInterface
    {
        public string Name { get; private set; }
        public int Age { get; private set; }
        public long Id { get; private set; }

        public Citizen(string name , int age , long id )
        {
            this.Name = name;
            this.Age = age;
            this.Id = id;
        }
    }
}
